/*************************************************************************************************
 ************************************** SOFTWARE DISCLAIMER **************************************
 *************************************************************************************************

 --------------------------------------IMPORTANT NOTICE-------------------------------------------

 1.	The Software is provided 'as is' without warranty of any kind, either express or implied,
    including, but not limited to, the implied warranties of fitness for a purpose, or the
    warranty of non-infringement.
 2.	Without limiting the foregoing, Patsystems makes no warranty that:
    (a)	the software will meet your requirements
    (b)	the software will be uninterrupted, timely, secure or error-free
    (c)	the results that may be obtained from the use of the software will be effective,
        accurate or reliable
    (d)	the quality of the software will meet your expectations
    (e)	any errors in the software obtained from Patsystems web site will be corrected.
 3.	Further the Software and its documentation made available:
    �	could include technical or other mistakes, inaccuracies or typographical errors.
        Patsystems may make changes to the software or documentation at its discretion.
    �	may be out of date, and Patsystems makes no commitment to update such materials.
 4.	Patsystems assumes no responsibility for errors or omissions in the software or
    documentation available from its web site and the software.
 5.	To the fullest extend permittable by law, in no event shall Patsystems be liable to you
    or kind, or any damages whatsoever, including, without limitation, those resulting from
    loss of use, data or profits, whether or not Patsystems has been advised of the possibility
    of such damages, and on any theory of liability, arising out of or in connection with the
    use of this software.
 6.	The use of the software is done at your own discretion and risk and with agreement that
    you will be solely responsible for any damage to your computer system or loss of data
    that results from such activities. No advice or information, whether oral or written,
    obtained by you from Patsystems or from Patsystems web site shall create any warranty
    for the software.

/*************************************************************************************************
 *************************************** COPYRIGHT NOTICE ****************************************
 *************************************************************************************************

 The disclosure, copying or distribution of the Software is prohibited and may be unlawful. The
 contents of the Software are copyright � Patsystems UK Limited. All rights are expressly reserved.

 Any content printed or otherwise may not be sold, licensed, transferred, copied or reproduced in
 whole or in part in any manner or in or on any media to any person without the prior written
 consent of Patsystems UK Limited.

 *************************************************************************************************/


package com.patsystems;

import patsystems.api.delphi.ClientAPI;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.Dimension;

import com.patsystems.selector.Selector;
import com.patsystems.subscriber.Subscriber;
import com.patsystems.orders.TradeTicket;
import com.patsystems.orders.OrderBook;
import com.patsystems.orders.CancelOrder;
import com.patsystems.orders.AmendOrder;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * <h1>GUIToolbar</h1>
 * <p>This is a grid of buttons which will allow the user to bring up windows
 * to make method calls on the Demo API.</p>
 * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
 *
 * @author ACloud (coder)
 * @author JSharpe (documents and reviewer)
 * @version "%I%, %G%"
 * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
 * @since (Java Demo App) version 1.0
 */

public class GUIToolbar extends JFrame implements ActionListener
{

    /**
     * <p>This is the copyright notice for this class </p>
     *
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     */
    public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

    public Selector selector;
    public OrderBook orderBook;

    protected ClientAPI clientAPI;

    private JButton buttonSelector;
    private JButton buttonSubscriber;
    private JButton buttonTradeTicket;
    private JButton buttonOrderBook;
    private JButton buttonCancelOrder;
    private JButton buttonAmendOrder;

    public final int toolBarHeight = 75;

    /**
     * constructor
     *
     * @param clientAPI
     */
    public GUIToolbar(ClientAPI clientAPI)
    {
        this.clientAPI = clientAPI;
    }

    /**
     * initiates the GUI Toolbar
     */
    public void init()
    {
        Dimension wndSize = Toolkit.getDefaultToolkit().getScreenSize();
        setTitle("Java Demo");
        setBounds(0, 0, wndSize.width, toolBarHeight);

        JPanel panelMain = new JPanel();
        panelMain.setLayout(new GridLayout(1, 5));

        buttonSelector = new JButton("Selector");
        buttonSelector.addActionListener(this);
        buttonSubscriber = new JButton("Subscriber");
        buttonSubscriber.addActionListener(this);
        buttonTradeTicket = new JButton("Trade Ticket");
        buttonTradeTicket.addActionListener(this);
        buttonOrderBook = new JButton("Order Book");
        buttonOrderBook.addActionListener(this);
        buttonCancelOrder = new JButton("Cancel Order");
        buttonCancelOrder.addActionListener(this);
        buttonAmendOrder = new JButton("Amend Order");
        buttonAmendOrder.addActionListener(this);

        panelMain.add(buttonSelector);
        panelMain.add(buttonSubscriber);
        panelMain.add(buttonTradeTicket);
        panelMain.add(buttonOrderBook);
        panelMain.add(buttonCancelOrder);
        panelMain.add(buttonAmendOrder);

        add(panelMain);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    /**
     * handles the user events of button clicks to create the trading tools within the Java Demo App
     *
     * @param e the action event
     */
    public void actionPerformed(ActionEvent e)
    {
        JButton button = (JButton) e.getSource();
        if (button == buttonSelector)
        {
            if (selector == null)
            {
                selector = new Selector(clientAPI);
                selector.init();
            }
            else
            {
                selector.setVisible(true);
            }

        }
        else
            if (button == buttonSubscriber)
            {
                Subscriber subscriber = new Subscriber(clientAPI);
                subscriber.init();
            }
            else
            {
                if (button == buttonTradeTicket)
                {
                    TradeTicket ticketTrade = new TradeTicket(clientAPI);
                    ticketTrade.init();
                }
                else if (button == buttonOrderBook)
                {
                    if (orderBook == null)
                    {
                        orderBook = new OrderBook(clientAPI);
                        orderBook.init();
                    }
                    else
                        orderBook.setVisible(true);
                }
                else if (button == buttonCancelOrder)
                {
                    CancelOrder cancelOrder = new CancelOrder(clientAPI);
                    cancelOrder.init();
                }
                else if (button == buttonAmendOrder)
                {
                    AmendOrder amendOrder = new AmendOrder(clientAPI);
                    amendOrder.init();
                }
            }
    }
}
