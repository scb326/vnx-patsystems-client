/*************************************************************************************************
 ************************************** SOFTWARE DISCLAIMER **************************************
 *************************************************************************************************

 --------------------------------------IMPORTANT NOTICE-------------------------------------------

 1.	The Software is provided 'as is' without warranty of any kind, either express or implied,
    including, but not limited to, the implied warranties of fitness for a purpose, or the
    warranty of non-infringement.
 2.	Without limiting the foregoing, Patsystems makes no warranty that:
    (a)	the software will meet your requirements
    (b)	the software will be uninterrupted, timely, secure or error-free
    (c)	the results that may be obtained from the use of the software will be effective,
        accurate or reliable
    (d)	the quality of the software will meet your expectations
    (e)	any errors in the software obtained from Patsystems web site will be corrected.
 3.	Further the Software and its documentation made available:
    �	could include technical or other mistakes, inaccuracies or typographical errors.
        Patsystems may make changes to the software or documentation at its discretion.
    �	may be out of date, and Patsystems makes no commitment to update such materials.
 4.	Patsystems assumes no responsibility for errors or omissions in the software or
    documentation available from its web site and the software.
 5.	To the fullest extend permittable by law, in no event shall Patsystems be liable to you
    or kind, or any damages whatsoever, including, without limitation, those resulting from
    loss of use, data or profits, whether or not Patsystems has been advised of the possibility
    of such damages, and on any theory of liability, arising out of or in connection with the
    use of this software.
 6.	The use of the software is done at your own discretion and risk and with agreement that
    you will be solely responsible for any damage to your computer system or loss of data
    that results from such activities. No advice or information, whether oral or written,
    obtained by you from Patsystems or from Patsystems web site shall create any warranty
    for the software.

/*************************************************************************************************
 *************************************** COPYRIGHT NOTICE ****************************************
 *************************************************************************************************

 The disclosure, copying or distribution of the Software is prohibited and may be unlawful. The
 contents of the Software are copyright � Patsystems UK Limited. All rights are expressly reserved.

 Any content printed or otherwise may not be sold, licensed, transferred, copied or reproduced in
 whole or in part in any manner or in or on any media to any person without the prior written
 consent of Patsystems UK Limited.

 *************************************************************************************************/


package com.patsystems;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;


import patsystems.api.delphi.ClientAPI;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * <h1>LoginScreen </h1>
 * <p>The Login Screen allows the user to either login or exit the App.</p>
 * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
 *
 * @author ACloud (coder)
 * @author JSharpe (documents and reviewer)
 * @version "%I%, %G%"
 * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
 * @since (Java Demo App) version 1.0
 */

public class LoginScreen extends JFrame implements ActionListener
{
    /**
     * <p>This is the copyright notice for this class </p>
     *
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     */
    public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

    public JLabel textStatus;
    protected ClientAPI clientAPI;
    private JButton buttonLogin;
    private JButton buttonCancel;

    final int screenWidth = 200;
    final int screenHeight = 125;

    /**
     * constructor
     */
    public LoginScreen()
    {

        buttonLogin = new JButton("Login");
        buttonLogin.addActionListener(this);
        buttonCancel = new JButton("Cancel");
        buttonCancel.addActionListener(this);

        textStatus = new JLabel("Awaiting user instruction");

        JPanel panelMain = new JPanel();
        panelMain.setLayout(new GridLayout(3, 1));

        panelMain.add(buttonLogin);
        panelMain.add(buttonCancel);
        panelMain.add(textStatus);
        panelMain.setVisible(true);

        setTitle("Login");
        setLayout(new FlowLayout());
        add(panelMain);
        setSize(new Dimension(screenWidth, screenHeight));

        Toolkit toolKit = Toolkit.getDefaultToolkit();
        Dimension wndSize = toolKit.getScreenSize();
        setLocation((wndSize.width - screenWidth) / 2, (wndSize.height - screenHeight) / 2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true);
    }

    /**
     * Processes the users request to either login or exit the Java Demo App.
     *
     * @param e ActionEvent
     */
    public void actionPerformed(ActionEvent e)
    {
        JButton button = (JButton) e.getSource();
        if (button == buttonLogin)
        {
            clientAPI = new ClientAPI(this);
        }
        else if (button == buttonCancel)
        {
            System.exit(0);
        }
    }

}
