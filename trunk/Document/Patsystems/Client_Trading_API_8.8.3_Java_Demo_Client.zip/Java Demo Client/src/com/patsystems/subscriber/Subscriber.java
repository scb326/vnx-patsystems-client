/*************************************************************************************************
 ************************************** SOFTWARE DISCLAIMER **************************************
 *************************************************************************************************

 --------------------------------------IMPORTANT NOTICE-------------------------------------------

 1.	The Software is provided 'as is' without warranty of any kind, either express or implied,
    including, but not limited to, the implied warranties of fitness for a purpose, or the
    warranty of non-infringement.
 2.	Without limiting the foregoing, Patsystems makes no warranty that:
    (a)	the software will meet your requirements
    (b)	the software will be uninterrupted, timely, secure or error-free
    (c)	the results that may be obtained from the use of the software will be effective,
        accurate or reliable
    (d)	the quality of the software will meet your expectations
    (e)	any errors in the software obtained from Patsystems web site will be corrected.
 3.	Further the Software and its documentation made available:
    �	could include technical or other mistakes, inaccuracies or typographical errors.
        Patsystems may make changes to the software or documentation at its discretion.
    �	may be out of date, and Patsystems makes no commitment to update such materials.
 4.	Patsystems assumes no responsibility for errors or omissions in the software or
    documentation available from its web site and the software.
 5.	To the fullest extend permittable by law, in no event shall Patsystems be liable to you
    or kind, or any damages whatsoever, including, without limitation, those resulting from
    loss of use, data or profits, whether or not Patsystems has been advised of the possibility
    of such damages, and on any theory of liability, arising out of or in connection with the
    use of this software.
 6.	The use of the software is done at your own discretion and risk and with agreement that
    you will be solely responsible for any damage to your computer system or loss of data
    that results from such activities. No advice or information, whether oral or written,
    obtained by you from Patsystems or from Patsystems web site shall create any warranty
    for the software.

/*************************************************************************************************
 *************************************** COPYRIGHT NOTICE ****************************************
 *************************************************************************************************

 The disclosure, copying or distribution of the Software is prohibited and may be unlawful. The
 contents of the Software are copyright � Patsystems UK Limited. All rights are expressly reserved.

 Any content printed or otherwise may not be sold, licensed, transferred, copied or reproduced in
 whole or in part in any manner or in or on any media to any person without the prior written
 consent of Patsystems UK Limited.

 *************************************************************************************************/


package com.patsystems.subscriber;

import patsystems.api.delphi.ClientAPI;
import patsystems.api.delphi.Commodity;
import patsystems.api.delphi.Contract;
import patsystems.api.delphi.PriceComposite;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Enumeration;

/**
 * <h1>Subscriber</h1>
 * <p>Allows the user to suscribe and unsubscribe to prices for a single contract date</p>
 * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
 *
 * @author ACloud (coder)
 * @author JSharpe (documents and reviewer)
 * @version "%I%, %G%"
 * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
 * @since (Java Demo App) version 1.0
 */

public class Subscriber extends JFrame implements ActionListener
{
    /**
     * <p>This is the copyright notice for this class </p>
     *
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     */
    public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";


    protected ClientAPI clientAPI;
    protected JComboBox comboExchanges = new JComboBox();
    protected JComboBox comboCommodities = new JComboBox();
    protected JComboBox comboContracts = new JComboBox();
    protected JButton buttonSubscribe;
    protected JButton buttonUnsubscribe;
    protected JLabel labelBidPrice;
    protected JLabel labelOfferPrice;
    protected JLabel labelLastPrice;
    protected JLabel labelBidVolume;
    protected JLabel labelOfferVolume;
    protected JLabel labelLastVolume;

    /**
     * Each subscriber can display prices for a single contract date. The <code>subscribedItem</code>
     * will contain the data of the currently subscribed contract so when the subscriber is closed or
     * a different contract is subscribed to, the previous contract date can be unsubscribed to.
     */
    protected SubscribedItem subscribedItem;

    /**
     * Constructor
     *
     * @param clientAPI
     */
    public Subscriber(ClientAPI clientAPI)
    {
        this.clientAPI = clientAPI;
    }

    /**
     * Initialises the subscriber
     */
    public void init()
    {
        setTitle("Subscriber");
        Dimension wndSize = Toolkit.getDefaultToolkit().getScreenSize();
        int width = wndSize.width / 3;
        int height = 175;
        setBounds((wndSize.width - width) / 2, (wndSize.height - height) / 2, width, height);

        JPanel panelTop = new JPanel();
        panelTop.setLayout(new GridLayout(4, 3));

        JLabel labelExchanges = new JLabel("Exchange");
        JLabel labelCommodities = new JLabel("Commodity");
        JLabel labelContract = new JLabel("Contract");
        comboExchanges = new JComboBox();
        comboExchanges.addActionListener(this);
        comboCommodities = new JComboBox();
        comboCommodities.addActionListener(this);
        comboContracts = new JComboBox();
        comboContracts.addActionListener(this);
        labelBidPrice = new JLabel("Bid Price = ");
        labelOfferPrice = new JLabel("Offer Price = ");
        labelLastPrice = new JLabel("Last Price = ");
        labelBidVolume = new JLabel("Bid Volume = ");
        labelOfferVolume = new JLabel("Offer Volume = ");
        labelLastVolume = new JLabel("Last Volume = ");

        panelTop.add(labelExchanges);
        panelTop.add(labelCommodities);
        panelTop.add(labelContract);
        panelTop.add(comboExchanges);
        panelTop.add(comboCommodities);
        panelTop.add(comboContracts);
        panelTop.add(labelBidPrice);
        panelTop.add(labelOfferPrice);
        panelTop.add(labelLastPrice);
        panelTop.add(labelBidVolume);
        panelTop.add(labelOfferVolume);
        panelTop.add(labelLastVolume);

        populateExchangeComboxBox();

        JPanel panelBottom = new JPanel();
        panelBottom.setLayout(new GridLayout(1, 2));

        buttonSubscribe = new JButton("Subscribe");
        buttonSubscribe.addActionListener(this);
        buttonUnsubscribe = new JButton("Unsubscribe");
        buttonUnsubscribe.addActionListener(this);

        panelBottom.add(buttonSubscribe);
        panelBottom.add(buttonUnsubscribe);

        setLayout(new BorderLayout());
        add(panelTop, BorderLayout.NORTH);
        add(panelBottom, BorderLayout.SOUTH);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        setVisible(true);

    }

    /**
     * destroys the subscriber object and unsubscribes to the currently subscribed contract date
     */
    public void dispose()
    {
        if (subscribedItem != null)
            try
            {
                unsubscribe(subscribedItem.exchange, subscribedItem.commodity, subscribedItem.contract);
            }
            catch (Exception e)
            {
                e.printStackTrace();
                clientAPI.logFile.addMessage(e.getMessage());
            }
    }

    /**
     * populates the exchange combo box with all the exchanges stored within the Java Demo App
     */
    private void populateExchangeComboxBox()
    {
        Enumeration<String> keys = clientAPI.exchangeMap.keys();
        while (keys.hasMoreElements())
            comboExchanges.addItem(keys.nextElement());
        populateCommodityComboxBox((String) comboExchanges.getSelectedItem());
    }

    /**
     * populates the commodity combo box with all the commodities within the specified exchange
     *
     * @param exchange
     */
    private void populateCommodityComboxBox(String exchange)
    {
        comboCommodities.removeAllItems();
        if (!exchange.equalsIgnoreCase(""))
        {
            Enumeration<String> keys = clientAPI.commodityMap.keys();
            while (keys.hasMoreElements())
            {
                Commodity commodity = clientAPI.commodityMap.get(keys.nextElement());
                if (commodity.exchange.name.equalsIgnoreCase(exchange))
                    comboCommodities.addItem(commodity.name);
            }
        }

        populateContractComboxBox((String) comboExchanges.getSelectedItem(), (String) comboCommodities.getSelectedItem());

    }

    /**
     * populates the contract combo box with all available contract dates for the corresponding
     * exchange and commodity
     *
     * @param exchange
     * @param commodity
     */
    private void populateContractComboxBox(String exchange, String commodity)
    {
        comboContracts.removeAllItems();
        if (exchange != "" && commodity != "")
        {
            Enumeration<String> keys = clientAPI.contractMap.keys();
            while (keys.hasMoreElements())
            {
                Contract contract = clientAPI.contractMap.get(keys.nextElement());
                if (contract.exchange.name == exchange && contract.commodity.name == commodity)
                    comboContracts.addItem(contract.name);
            }
        }
    }

    /**
     * subscribes to the selected contract
     *
     * @throws Exception
     */
    private void subscribe() throws Exception
    {

        String exchange = (String) comboExchanges.getSelectedItem();
        String commodity = (String) comboCommodities.getSelectedItem();
        String contract = (String) comboContracts.getSelectedItem();

        if (exchange == "" | commodity == "" | contract == "")
            clientAPI.logFile.addMessage("Cannot subscribe to " + exchange + " / " + commodity + " / " + contract);
        else
        {
            //BEFORE SUBSCRIBING TO ONE CONTRACT WE MUST UNSUBSCRIBE TO THE PREVIOUS CONTRACT, IF WE HAVE A
            //SUBSCRIBED CONTRACT
            if (subscribedItem != null)
                unsubscribe(subscribedItem.exchange, subscribedItem.commodity, subscribedItem.contract);

            if (!clientAPI.subscriberMap.containsKey(exchange + " / " + commodity + " / " + contract))
            {
                clientAPI.doSubscribe(exchange, commodity, contract);
                setTitle("Subscriber : " + exchange + " / " + commodity + " / " + contract);

                //WILL STORE A REFERENCE TO THE SUBSCRIBER WINDOW SO WHEN PRICE UPDATES ARE RECEIVED THEY CAN BE
                //SENT TO THE SUBSCRIBER TO BE DISPLAYED
                clientAPI.subscriberMap.put(exchange + " / " + commodity + " / " + contract, this);

                //HERE WE WILL STORE THE DETAILS OF THE SUBSCRIBED CONTRACT TO USE WHEN WE NEED TO UNSUBSCRIBE
                if (subscribedItem == null)
                    subscribedItem = new SubscribedItem(exchange, commodity, contract);
                else
                {
                    subscribedItem.exchange = exchange;
                    subscribedItem.commodity = commodity;
                    subscribedItem.contract = contract;
                }
            }
            else
                JOptionPane.showMessageDialog(this, "Cannot resubscribe to a contract that is already subscribed to in another window");
        }
    }

    /**
     * unsubscribes to the specified contract date
     *
     * @param exchange
     * @param commodity
     * @param contract
     * @throws Exception
     */
    private void unsubscribe(String exchange, String commodity, String contract) throws Exception
    {

        if (exchange == "" | commodity == "" | contract == "")
            clientAPI.logFile.addMessage("Cannot unsubscribe to " + exchange + " / " + commodity + " / " + contract);
        else
        {
            if (subscribedItem != null)
            {
                if (subscribedItem.exchange == exchange && subscribedItem.commodity == commodity &&
                        subscribedItem.contract == contract)
                {
                    clientAPI.doUnsubscribe(exchange, commodity, contract);
                    subscribedItem = null;

                    // REMOVE A REFERENCE OF THIS SUBSCRIBER FROM THE CLIENTAPI OBJECT
                    if (clientAPI.subscriberMap.containsKey(exchange + " / " + commodity + " / " + contract))
                        clientAPI.subscriberMap.remove(exchange + " / " + commodity + " / " + contract, this);
                }
                else
                    JOptionPane.showMessageDialog(this, "Cannot unsubscribe to a contract you have not subscribed to in this window");
            }
        }
    }

    /**
     * receives the prices for the contract date and updates the subscriber accordingly
     *
     * @param prices
     */
    public void priceUpdate(PriceComposite prices)
    {
        labelBidPrice.setText(" Bid Price= " + prices.bid.price);
        labelBidVolume.setText(" Bid Volume= " + String.valueOf(prices.bid.volume));
        labelOfferPrice.setText(" Offer Price= " + prices.offer.price);
        labelOfferVolume.setText(" Offer Volume=" + String.valueOf(prices.offer.volume));
        labelLastPrice.setText(" Last Price= " + prices.last[0].price);
        labelLastVolume.setText(" Last Volume=" + prices.last[0].volume);
    }

    public void actionPerformed(ActionEvent e)
    {

        if (e.getSource() == comboExchanges)
            populateCommodityComboxBox((String) comboExchanges.getSelectedItem());
        else
            if (e.getSource() == comboCommodities)
                populateContractComboxBox((String) comboExchanges.getSelectedItem(), (String) comboCommodities.getSelectedItem());
            else if (e.getSource() == buttonSubscribe)
            {
                try
                {
                    subscribe();
                }
                catch (Exception e1)
                {
                    e1.printStackTrace();
                    clientAPI.logFile.addMessage(e1.getMessage());
                }
            }
            else if (e.getSource() == buttonUnsubscribe)
            {
                try
                {
                    String exchange = (String) comboExchanges.getSelectedItem();
                    String commodity = (String) comboCommodities.getSelectedItem();
                    String contract = (String) comboContracts.getSelectedItem();

                    unsubscribe(exchange, commodity, contract);
                }
                catch (Exception e1)
                {
                    e1.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    clientAPI.logFile.addMessage(e1.getMessage());
                }
            }
    }

    /**
     *
     */

    /**
     * <h1></h1>
     * <p>
     * a class for containing the information about a subscribed contract:
     * <pre>
     * a Exchange
     * b Commodity
     * c Contract
     * </pre>
     * </p>
     * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
     * @author ACloud (coder)
     * @author JSharpe (documents and reviewer)
     * @version "%I%, %G%"
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     * @since (Java Demo App) version 1.0
     */
    private class SubscribedItem
    {
        /**
         * <p>This is the copyright notice for this class </p>
         *
         * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
         */
        public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

        protected String exchange;
        protected String commodity;
        protected String contract;

        public SubscribedItem(String exchange, String commodity, String contract)
        {
            this.exchange = exchange;
            this.commodity = commodity;
            this.contract = contract;
        }


    }


}
