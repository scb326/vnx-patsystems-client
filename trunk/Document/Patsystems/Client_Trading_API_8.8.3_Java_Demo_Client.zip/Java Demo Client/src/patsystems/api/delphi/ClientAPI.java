/*************************************************************************************************
 ************************************** SOFTWARE DISCLAIMER **************************************
 *************************************************************************************************

 --------------------------------------IMPORTANT NOTICE-------------------------------------------

 1.	The Software is provided 'as is' without warranty of any kind, either express or implied,
    including, but not limited to, the implied warranties of fitness for a purpose, or the
    warranty of non-infringement.
 2.	Without limiting the foregoing, Patsystems makes no warranty that:
    (a)	the software will meet your requirements
    (b)	the software will be uninterrupted, timely, secure or error-free
    (c)	the results that may be obtained from the use of the software will be effective,
        accurate or reliable
    (d)	the quality of the software will meet your expectations
    (e)	any errors in the software obtained from Patsystems web site will be corrected.
 3.	Further the Software and its documentation made available:
    �	could include technical or other mistakes, inaccuracies or typographical errors.
        Patsystems may make changes to the software or documentation at its discretion.
    �	may be out of date, and Patsystems makes no commitment to update such materials.
 4.	Patsystems assumes no responsibility for errors or omissions in the software or
    documentation available from its web site and the software.
 5.	To the fullest extend permittable by law, in no event shall Patsystems be liable to you
    or kind, or any damages whatsoever, including, without limitation, those resulting from
    loss of use, data or profits, whether or not Patsystems has been advised of the possibility
    of such damages, and on any theory of liability, arising out of or in connection with the
    use of this software.
 6.	The use of the software is done at your own discretion and risk and with agreement that
    you will be solely responsible for any damage to your computer system or loss of data
    that results from such activities. No advice or information, whether oral or written,
    obtained by you from Patsystems or from Patsystems web site shall create any warranty
    for the software.

/*************************************************************************************************
 *************************************** COPYRIGHT NOTICE ****************************************
 *************************************************************************************************

 The disclosure, copying or distribution of the Software is prohibited and may be unlawful. The
 contents of the Software are copyright � Patsystems UK Limited. All rights are expressly reserved.

 Any content printed or otherwise may not be sold, licensed, transferred, copied or reproduced in
 whole or in part in any manner or in or on any media to any person without the prior written
 consent of Patsystems UK Limited.

 *************************************************************************************************/


package patsystems.api.delphi;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;

import com.patsystems.*;
import com.patsystems.LoginScreen;
import com.patsystems.GUIToolbar;
import com.patsystems.orders.OrdersHashMap;
import com.patsystems.subscriber.Subscriber;

/**
 * <h1>ClientAPI</h1>
 * <p>The clientapi will house all the direct method calls to and from the JavaWrapper.
 * It will contain all the variables that make up the trading session and is passed to
 * objects throughout the project
 * </p>
 * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
 *
 * @author ACloud (coder)
 * @author JSharpe (documents and reviewer)
 * @version "%I%, %G%"
 * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
 * @since (Java Demo App) version 1.0
 */

public class ClientAPI
{

    /**
     * <p>This is the copyright notice for this class </p>
     *
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     */
    public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

    final String wrapperFileName = "Javawrapper.DLL";

    public CallBackProcessor callbackThread;

    /**
     * msgBuff is a byte buffer used by the JavaWrapper and the Java Demo App for passing informtion back and forth
     */
    protected static byte[] msgBuff = new byte[8192]; // Buffer for messages between PATS API and Java Client
    /**
     * logFile is a refrence to the log file
     */
    public Logging logFile;
    /**
     * accountMap is a thread safe HashMap. Which contains all the Trader Accounts where the unique key is the Account name
     */
    public ConcurrentHashMap<String, TraderAccount> accountMap;
    /**
     * exchangetMap is a thread safe HashMap. Which contains all the Exchanges where the unique key is the Exchange name
     */
    public ConcurrentHashMap<String, Exchange> exchangeMap;
    /**
     * commodityMap is a thread safe HashMap. Which contains all the Commodities where the unique key is the Exchange
     * name + "/" + Commodity name
     */
    public ConcurrentHashMap<String, Commodity> commodityMap;
    /**
     * contractMap is a thread safe HashMap. Which contains all the Contracts where the unique key is the Exchange
     * name + "/" + Commodity name + "/" + Contract name
     */
    public ConcurrentHashMap<String, Contract> contractMap;
    /**
     * reportMap is a thread HashMap. Which contains all of the reports where the unique key is the report type
     */
    public ConcurrentHashMap<String, String> reportMap;
    /**
     * orderTypeMap is a thread safe HashMap. Which contains all of the order types where the unique key is the
     * exchange name + "/" order type name
     */
    public ConcurrentHashMap<String, OrderType> orderTypeMap;
    /**
     * subscribeMap is a thread safe HashMap. Which contains all the subscribers that exist within the application.
     */
    public ConcurrentHashMap<String, Subscriber> subscriberMap;
    /**
     * orderMap is a HashMap that inherits from ConcurrentHashMap. Which contains all the orders received by the
     * Java Demo App.
     */
    public OrdersHashMap<String, Order> orderMap;

    /**
     * workingDir is a string of the location of the JavaWrapper, DemoAPI.Dll and where all the demo data files are stored
     */
    public String workingDir;
    /**
     * loginScreen is a reference to the loginScreen
     */
    public LoginScreen loginScreen;
    /**
     * guiToolbar is a refernce to the main toolbar in the Java Demo App
     */
    public GUIToolbar guiToolbar;

    public ClientAPI(LoginScreen loginFrame)
    {
        try
        {
/*
            Workingdir is the location of the javawrapper, demoapi.dll and where the error log
            file will be located. It is important that this location does not change within
            the structure of the project as the following method to find the apidemodata
            directory will not work
*/
            workingDir = System.getProperty("user.dir");
            workingDir = workingDir.substring(0, workingDir.lastIndexOf("\\"));
            workingDir = workingDir + "\\apidemodata\\";

            loginScreen = loginFrame;
            logFile = new Logging(workingDir);

            initialiseClient();

            loginScreen.textStatus.setText("Initialising the API");
        }
        catch (Throwable e)
        {
            e.printStackTrace();
            logFile.addMessage(e.getMessage());
        }
    }

    /**
     * <h1>initialiseClient()</h1>
     * <p>This is the method that allows the:</p>
     * <pre>
     *  a   initialisation of the API
     *  b   initialises the connections to the <code>host</code> and <code>prices</code>
     *  c   initialise the callback thread[1]
     * </pre>
     * [1] The callback thread is where the Java/Delphi comminicates and the delphi pushes
     * information into the Java API</p>
     */

    protected void initialiseClient() throws Exception
    {
        //CREATE ALL THE STRUCTURES FOR THE CLIENTAPI

        exchangeMap = new ConcurrentHashMap<String, Exchange>();
        accountMap = new ConcurrentHashMap<String, TraderAccount>();
        commodityMap = new ConcurrentHashMap<String, Commodity>();
        contractMap = new ConcurrentHashMap<String, Contract>();
        orderTypeMap = new ConcurrentHashMap<String, OrderType>();
        reportMap = new ConcurrentHashMap<String, String>();
        subscriberMap = new ConcurrentHashMap<String, Subscriber>();
        orderMap = new OrdersHashMap<String, Order>();
        orderMap.assignClientAPI(this);

        //LOAD THE DLL
        System.load(workingDir + wrapperFileName);

        //START THE API AND LOGIN
        doInitialise();
        doSetDebugFlags(255);
        String[] hosts = {""};
        String[] prices = {""};
        doOpenConnections(hosts, prices);
        loginScreen.textStatus.setText("Logging into API");
        doLogin("", "", "", true, true);
        callbackThread = new CallBackProcessor();
        callbackThread.start();
    }

    /**
     * getAPIData retrieves all of the Exchanges, Commodities Order Types etc. from
     * the Delphi API and stores them within hashmaps
     *
     * @throws Exception
     */
    protected void getAPIData() throws Exception
    {
        byte[] buffer = new byte[8192];
//DOWNLOAD THE TRADER ACCOUNTS
        int[] count = doCountAccounts();
        loginScreen.textStatus.setText("Downloading Trader Accounts");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetAccount(index);
                TraderAccount account = new TraderAccount(buffer);
                accountMap.put(account.getKey(), account);
            }
        }
//DOWNLOAD THE EXCHANGES
        count = doCountExchanges();
        loginScreen.textStatus.setText("Downloading Exchanges");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetExchange(index);
                Exchange exchange = new Exchange(buffer);
                exchangeMap.put(exchange.getKey(), exchange);
            }
        }
//DOWNLOAD THE COMMODITIDES
        count = doCountCommodities();
        loginScreen.textStatus.setText("Downloading Commodities");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetCommodity(index);
                Commodity commodity = new Commodity(buffer, this);
                commodityMap.put(commodity.getKey(), commodity);
            }
        }

//DOWNLOAD THE CONTRACTS
        count = doCountContracts();
        loginScreen.textStatus.setText("Downloading Contracts");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetContract(index);
                Contract contract = new Contract(buffer, this);
                contractMap.put(contract.getKey(), contract);
            }
        }

//DOWNLOAD THE ORDERTYPES
        count = doCountOrderTypes();
        loginScreen.textStatus.setText("Downloading Order Types");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetOrderType(index);
                OrderType orderType = new OrderType(buffer, this);
                orderTypeMap.put(orderType.getKey(), orderType);
            }
        }

        //DOWNLOAD THE REPORTS
        count = doCountReportTypes();
        loginScreen.textStatus.setText("Downloading Report Types");
        if (count[0] > 0)
        {
            for (int index = 0; index < count[0]; index++)
            {
                buffer = doGetReportType(index);
                String reportType = getReportType(buffer);
                int[] reportSize = doGetReportSize(reportType);
                byte[] reportBuffer = doGetReport(reportType, reportSize[0]);
                String report = getReport(reportBuffer, reportSize[0]);
                reportMap.put(reportType, report);
            }
        }

        logFile.addMessage("Trader Accounts downloaded = " + accountMap.size());
        logFile.addMessage("Exchanges downloaded = " + exchangeMap.size());
        logFile.addMessage("Commodities downloaded = " + commodityMap.size());
        logFile.addMessage("Contracts downloaded = " + contractMap.size());
        logFile.addMessage("Order Types downloaded = " + orderTypeMap.size());
        logFile.addMessage("Reports downloaded = " + reportMap.size());

        //ONCE THE CLIENTAPI IS STARTED THE LOGIN SCREEN CAN DISAPPEAR AND LOAD UP THE MAIN GUI
        loginScreen.dispose();
        loginScreen = null;
        guiToolbar = new GUIToolbar(this); // LAUNCH THE MAIN GUI
        guiToolbar.init();
    }

    /**
     * getReportType takes in the Byte buffer and returns the report type
     *
     * @param buffer
     */
    private String getReportType(byte[] buffer)
    {
        ByteArrayFetcher fetcher = new ByteArrayFetcher(buffer);
        return fetcher.getString(StructDefinitions.SIZE_REPORT_TYPE);

    }

    /**
     * getReport takes in the byte Buffer and returns the report
     *
     * @param buffer
     * @param reportSize
     */
    private String getReport(byte[] buffer, int reportSize)
    {
        ByteArrayFetcher fetcher = new ByteArrayFetcher(buffer);
        return fetcher.getString(reportSize);
    }

/************************************************************************************
 *THE FOLLOWING CODE STARTS A THREAD TO HANDLE THE CALLBACKS FROM THE PATS DELPHI API
 ************************************************************************************/

    /**
     * <h1>CallBackProcessor</h1>
     * <p>
    * CallBackProcessor is a thread that handles all the callbacks sent to the Java Demo App
     * from the JavaWrapper.
     *  * </p>
     * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
     * @author ACloud (coder)
     * @author JSharpe (documents and reviewer)
     * @version "%I%, %G%"
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     * @since (Java Demo App) version 1.0
     */
    class CallBackProcessor implements Runnable
    {
        /**
         * <p>This is the copyright notice for this class </p>
         *
         * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
         */
        public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

        private Thread runner = null;
        private boolean running=true;

        CallBackProcessor()
        {
        }

        /**
         *{@inheritDoc}
         */
        public void run()
        {
            while (running)
            {
                processCallbacks(msgBuff);
            }
        }

        /**
         * start the thread running
         */
        public void start()
        {
            if (!isRunning())
            {
                runner = new Thread(this);
                runner.start();
            }
        }

        /**
         * checks to see if the thread is running
         */
        public boolean isRunning()
        {
            return (runner != null && runner.isAlive());
        }

        /**
         * stops the thread running
         */
        public void stopThisCallBackThread()
        {
            running=false;
        }
    }


//*********************************************************************************
// THE FOLLOWING CODE IS THE BEGINNING OF THE ORDER HANDLING THREAD - IT DOES NOTHING SO FAR - NEEDS TO BE CODED
//**********************************************************************************

    /**
     * <h1>OrdersProcessor</h1>
     * <p>Order process class</p>
     * <p>Copyright <B>Patsystems UK Limited 2000-2007</b></p>
     * @author ACloud (coder)
     * @author JSharpe (documents and reviewer)
     * @version "%I%, %G%"
     * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
     * @since (Java Demo App) version 1.0
     */
    class OrdersProcessor implements Runnable
    {
        /**
         * <p>This is the copyright notice for this class </p>
         *
         * @copyright<br><p><B>Patsystems UK Limited 2000-2007</b></p>
         */
        public static final String COPYRIGHT = "Copyright (c) Patsystems UK Limited 2000-2007";

        OrdersProcessor()
        {
        }

        public void run()
        {
            //your code to handle the order here...
        }
    }

/********************************************************************************************
 * HERE ARE ALL THE METHODS TO CALL API FUNCTIONS
 * @throws Exception
 * *****************************************************************************************/
    /**
     * check takes in the result of a method call to the JavaWrapper and if it is not a success,
     * records the error in the log file along with the method name.
     *
     * @param result int
     * @param msg    String
     * @throws Exception
     */
    public void check(int result, String msg) throws Exception
    {
        if (result != APIConstants.ptSuccess)
        {
            String errorMessage = doGetErrorMessage(result) + " in " + msg;
            JOptionPane.showMessageDialog(null, errorMessage);
            Calendar cal = new GregorianCalendar();
            int hour24 = cal.get(Calendar.HOUR_OF_DAY);
            int min = cal.get(Calendar.MINUTE);
            int sec = cal.get(Calendar.SECOND);
            int ms = cal.get(Calendar.MILLISECOND);
            String time = String.valueOf(hour24) + ":" +
                    String.valueOf(min) + ":" +
                    String.valueOf(sec) + ":" +
                    String.valueOf(ms);
            logFile.addMessage(time + "\t" + errorMessage);
        }
    }

//	INITIALISE

    /**
     * calls Initialise in the JavaWrapper
     *
     * @throws Exception
     */
    public void doInitialise() throws Exception
    {
        check(initialise(workingDir, workingDir, true, false, false, "patsFred", true), "doInitialise");
    }

//ENABLE LOGGING LEVEL

    /**
     * sets the level of diagnostics
     *
     * @throws Exception
     */
    public void doSetDebugFlags(int Logging) throws Exception
    {
        check(setDebugFlags(Logging), "doSetDebugFlags");
    }

//OPEN CONNECTIONS - PTREADY

    /**
     * Sets the host and price IP addresses and ports
     *
     * @param hosts  String[]
     * @param prices String[]
     * @throws Exception
     */
    public void doOpenConnections(String[] hosts, String[] prices) throws Exception
    {
        check(openConnections(hosts, prices), "doOpenConnections");
    }

//LOGON

    /**
     * Logs onto the Demo Trading Environment
     *
     * @param user        String
     * @param password    String
     * @param newPassword String
     * @param reset       boolean
     * @param reports     boolean
     * @throws Exception
     */
    public void doLogin(String user, String password, String newPassword, boolean reset, boolean reports) throws Exception
    {
        check(logon(user, password, newPassword, reset, reports), "doLogon");
    }
//GET ERROR MESSAGE FROM API

    /**
     * doGetErrorMessage passes in an error code, returned from the JavaWrapper after each method call, and
     * returns a string translation of the error code.
     *
     * @param error int
     */
    public String doGetErrorMessage(int error)
    {
        String msg = getErrorMessage(error);
        return msg;
    }
//	LOGOFF

    /**
     * doLogoff ends the trading session
     *
     * @throws IOException
     */
    public void doLogoff() throws IOException
    {
        int status = logoff();
        if (status == 0)
        {
            logFile.closeFile();
            System.exit(0);
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Failed To Logoff", "Logoff", JOptionPane.ERROR_MESSAGE);
        }
    }
//COUNT NUMBER OF TRADER ACCOUNTS

    /**
     * doCountAccounts returns the total number of Trader Accounts
     *
     * @return
     * @throws Exception
     */
    public int[] doCountAccounts() throws Exception
    {
        int[] accountCount = new int[1];
        check(countAccounts(accountCount), "doCountAccounts");
        return accountCount;
    }
//	COUNT NUMBER OF EXCHANGES

    /**
     * doCountExchanges returns the total number of Exchanges
     *
     * @return
     * @throws Exception
     */
    public int[] doCountExchanges() throws Exception
    {
        int[] exchangeCount = new int[1];
        check(countExchanges(exchangeCount), "doCountExchanges");
        return exchangeCount;
    }
//	COUNT NUMBER OF COMMODITIES

    /**
     * doCountCommodities returns the total number of Commodities
     *
     * @return
     * @throws Exception
     */
    public int[] doCountCommodities() throws Exception
    {
        int[] commodityCount = new int[1];
        check(countCommodities(commodityCount), "doCountCommodities");
        return commodityCount;
    }
//	COUNT NUMBER OF CONTRACTS

    /**
     * doCountContracts returns the total number of Contracts
     *
     * @return
     * @throws Exception
     */
    public int[] doCountContracts() throws Exception
    {
        int[] contractCount = new int[1];
        check(countContracts(contractCount), "doCountContracts");
        return contractCount;
    }
//	COUNT NUMBER OF ORDER TYPES

    /**
     * doCountOrderTypes returns the total number of Order Types
     *
     * @return
     * @throws Exception
     */
    public int[] doCountOrderTypes() throws Exception
    {
        int[] otCount = new int[1];
        check(countOrderTypes(otCount), "doCountOrderTypes");
        return otCount;
    }
//	COUNT NUMBER OF REPORT TYPES

    /**
     * doCountReportTypes returns the total number of report types
     *
     * @return
     * @throws Exception
     */
    public int[] doCountReportTypes() throws Exception
    {
        int[] otCount = new int[1];
        check(countReportTypes(otCount), "doCountReportTypes");
        return otCount;
    }
//	 GET ACCOUNT STRUCT FROM THE API

    /**
     * doGetAccount takes in the Index and returns the Trader Account
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetAccount(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getAccount(index, buffer), "doGetAccount");
        return buffer;
    }
// GET EXCHANGE STRUCT FROM THE API

    /**
     * doGetExchange takes in the Index and returns the Exchange
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetExchange(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getExchange(index, buffer), "doGetExchange");
        return buffer;
    }

//GET COMMODITY STRUCT FROM THE API

    /**
     * doGetCommodity takes in the Index and returns the Commodity
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetCommodity(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getCommodity(index, buffer), "doGetCommodity");
        return buffer;
    }

//GET CONTRACT STRUCT FROM THE API

    /**
     * doGetContract takes in the Index and returns the Contract
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetContract(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getContract(index, buffer), "doGetContract");
        return buffer;
    }
//GET ORDER TYPE STRUCT FROM THE API

    /**
     * doGetOrderType tales in the Index and returns the Order Type
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetOrderType(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getOrderType(index, buffer), "doGetOrderType");
        return buffer;
    }
//GET REPORT TYPE STRUCT FROM THE API

    /**
     * doGetReportType takes in the Index and returns the Report Type
     *
     * @param index int
     * @return
     * @throws Exception
     */
    public byte[] doGetReportType(int index) throws Exception
    {
        byte[] buffer = new byte[8192];
        check(getReportType(index, buffer), "doGetReportType");
        return buffer;
    }
//GET REPORT SIZE STRUCT FROM THE API

    /**
     * dpGetReportSize takes in the name of the report type and returns the Report Size
     *
     * @param reportType String
     * @return
     * @throws Exception
     */
    public int[] doGetReportSize(String reportType) throws Exception
    {
        int[] size = new int[1];
        check(getReportSize(reportType, size), "doGetReportSize");
        return size;
    }
//GET REPORT SIZE STRUCT FROM THE API

    /**
     * doGetReport takes in the report type and the report szie and returns the report
     *
     * @param reportType String
     * @param reportSize int
     * @return
     * @throws Exception
     */
    public byte[] doGetReport(String reportType, int reportSize) throws Exception
    {
        byte[] report = new byte[reportSize];
        check(getReport(reportType, report), "doGetReport");
        return report;
    }
//SUBSCRIBE TO A CONTRACT

    /**
     * doSubscribe takes in the exchange, commodity and contract name and initiates receipt of prices
     *
     * @param exchange  String
     * @param commodity String
     * @param contract  String
     * @throws Exception
     */
    public void doSubscribe(String exchange, String commodity, String contract) throws Exception
    {
        check(subscribe(exchange, commodity, contract), "doSubscribe");
    }

//UNSUBSCRIBE TO A CONTRACT

    /**
     * doUnsubscribe stops the price updates for a contract specified by the exchange, commodity and contract
     *
     * @param exchange  String
     * @param commodity String
     * @param contract  String
     * @throws Exception
     */
    public void doUnsubscribe(String exchange, String commodity, String contract) throws Exception
    {
        check(unsubscribe(exchange, commodity, contract), "doUnsubscribe");
    }

//GET THE PRICE FOR A CONTRACT - CALLED AFTER THE CALLBACK IS TRIGGERED

    /**
     * doGetContractPrices takes in a byte buffer containing the exchange, commodity and contract name and
     * populates a byte buffer with the price information
     *
     * @param buffer Byte[]
     * @throws Exception
     */
    public void doGetContractPrices(byte[] buffer) throws Exception
    {
        ByteArrayFetcher fetcher = new ByteArrayFetcher(buffer);
        String exchange = fetcher.getString(StructDefinitions.SIZE_EXCHANGE_NAME);
        String commodity = fetcher.getString(StructDefinitions.SIZE_COMMODITY_NAME);
        String contract = fetcher.getString(StructDefinitions.SIZE_CONTRACT_NAME);
        byte[] priceBuffer = new byte[8192];

        check(getContractPrices(exchange, commodity, contract, priceBuffer), "doGetPriceForContract");
        PriceComposite prices = new PriceComposite(priceBuffer, this);

        //NOW WE HAVE TO FIND THE SUBSCRIBER OBJECT THAT SUBSCRIBED TO THE CONTRACT AND PASS THE PRICE DETAILS TO IT
        String key = exchange + " / " + commodity + " / " + contract;
        if (subscriberMap.containsKey(key))
            subscriberMap.get(key).priceUpdate(prices);
    }

//SEND AN ORDER TO THE DELPHI API.

    /**
     * doAddOrder takes in a new order buffer and sends the order request to the JavaWrapper
     *
     * @param buffer byte[]
     * @throws Exception
     */
    public void doAddOrder(byte[] buffer) throws Exception
    {
        check(addOrder(buffer), "doAddOrder");
    }

//GET THE ORDER BASED ON THE PATS ORDER ID

    /**
     * doGetOrderByID takes in a buffer containing the order ID and creates a byte array containing the
     * order details
     *
     * @param buffer byte[]
     * @throws Exception
     */
    public void doGetOrderByID(byte[] buffer) throws Exception
    {
        ByteArrayFetcher fetcher = new ByteArrayFetcher(buffer);
        String orderID = fetcher.getString(StructDefinitions.SIZE_ORDER_ID);
        byte[] orderDetails = new byte[StructDefinitions.SIZE_ORDER_DETAIL_STRUCT];
        check(getOrderById(orderID, orderDetails), "doGetOrderByID");
        Order order = new Order(orderDetails);
        orderMap.put(order.orderID, order);
        if (guiToolbar.orderBook != null)
        {
            guiToolbar.orderBook.invalidate();
            guiToolbar.orderBook.validate();
        }
    }

    //CANCEL AN EXISTING ORDER

    /**
     * doCancelOrder takes in an orderID and sends a cancel order request to the JavaWrapper
     *
     * @param orderID String
     * @throws Exception
     */
    public void doCancelOrder(String orderID) throws Exception
    {
        check(cancelOrder(orderID), "doCancelOrder");
    }

//AMEND AN EXISTING ORDER

    /**
     * doAmendOrder takes in an Order ID and a byte buffer containing the amended order details and sends a
     * request to the JavaWrapper to amend the order
     *
     * @param orderID String
     * @param buffer  byte[]
     * @throws Exception
     */
    public void doAmendOrder(String orderID, byte[] buffer) throws Exception
    {
        check(amendOrder(orderID, buffer), "doAmendOrder");
    }

//All the imported methods from the JavaWrapper:

    protected native int initialise(String runtimeDir, String logDir, boolean demo, boolean test, boolean connectivity, String applicationID, boolean reset);

    protected native int logon(String user, String pwd, String newPwd, boolean force, boolean reports);

    protected native int setDebugFlags(int Logging);

    protected native int openConnections(String[] hosts, String[] prices);

    protected native void processCallbacks(byte[] buffer);

    protected native String getErrorMessage(int error);

    protected native int logoff();

    protected native int countAccounts(int[] count);

    protected native int countExchanges(int[] count);

    protected native int countCommodities(int[] count);

    protected native int countContracts(int[] result);

    protected native int countOrderTypes(int[] count);

    protected native int countReportTypes(int[] count);

    protected native int getExchange(int index, byte[] buffer);

    protected native int getAccount(int index, byte[] buffer);

    protected native int getCommodity(int index, byte[] buffer);

    protected native int getContract(int index, byte[] buffer);

    protected native int getOrderType(int index, byte[] buffer);

    protected native int getReportType(int index, byte[] buffer);

    protected native int getReportSize(String report, int[] size);

    protected synchronized native int getReport(String report, byte[] buffer);

    protected native int subscribe(String exchange, String commodity, String contract);

    protected native int unsubscribe(String exchange, String commodity, String contract);

    protected native int getContractPrices(String exchange, String commodity, String contract, byte[] buffer);

    protected native int addOrder(byte[] buffer);

    protected native int getOrderById(String orderID, byte[] buffer);

    protected native int cancelOrder(String OrderID);

    protected native int amendOrder(String orderID, byte[] buffer);

/********************************************************************************************
 * THE FOLLOWING METHOD LINKS TO THE JAVAWRAPPER'S Java_patsystems_api_delphi_ClientAPI_processCallbacks
 * METHOD AND THEN CALLS PROCESSMESSAGE IN THIS JAVA APPLICATION TO PROCESS THE CALLBACKS, MESSAGEDRECEIVED
 * IS CALLED BY THE WRAPPER
 ********************************************************************************************/
    /**
     * messageReceived is called by the JavaWrapper when a new callback is sent from the Delphi API. This
     * method in turns calls processMessage which handles the different callbacks
     *
     * @param messageID int
     * @param length    int
     */
    protected void messageReceived(int messageID, int length)
    {
        processMessage(messageID, length, msgBuff);
    }

    /**
     * processMessage is called from messageReceived and processes all of the different callbacks received
     * from the JavaWrapper
     * @param messageID int
     * @param length int
     * @param buffer byte[]
     */
    protected void processMessage(int messageID, int length, byte[] buffer)
    {
        try
        {
            switch (messageID)
            {
            case APICallbacks.MID_HOST_LINK_CHANGE:
                break;
            case APICallbacks.MID_PRICE_LINK_CHANGE:
                break;
            case APICallbacks.MID_LOGON_STATUS:
                break;
            case APICallbacks.MID_MESSAGE:
                System.out.println("User message callback");
                break;
            case APICallbacks.MID_DOWNLOAD_COMPLETE:
                getAPIData();
                break;
            case APICallbacks.MID_CONTRACT_ADDED:
                System.out.println("Contract added callback");
                break;
            case APICallbacks.MID_CONTRACT_DELETED:
                System.out.println("Contract deleted callback");
                break;
            case APICallbacks.MID_BLANK_PRICE:
                System.out.println("Price blanking callback");
                break;
            case APICallbacks.MID_PRICE:
                doGetContractPrices(buffer);
                break;
            case APICallbacks.MID_SETTLEMENT_PRICE:
                System.out.println("Settlement price callback");
                break;
            case APICallbacks.MID_DOM_UPDATE:
                System.out.println("DOM callback");
                break;
            case APICallbacks.MID_STATUS:
                System.out.println("Status change callback");
                break;
            case APICallbacks.MID_AT_BEST_ID:
                System.out.println("Best message callback");
                break;
            case APICallbacks.MID_SUBSCRIBER_DEPTH:
                System.out.println("Subscriber Depth message callback");
                break;
            case APICallbacks.MID_GENERIC_PRICE:
                System.out.println("Generic price callback");
                break;
            case APICallbacks.MID_FILL:
                System.out.println("Fill callback");
                break;
            case APICallbacks.MID_ORDER:
                doGetOrderByID(buffer);
                break;
            case APICallbacks.MID_FORCED_LOGOUT:
                System.out.println("Forced logout callback");
                break;
            case APICallbacks.MID_EXCHANGE_RATE:
                System.out.println("Exchange rate callback");
                break;
            case APICallbacks.MID_CONNECTIVITY_STATUS:
                System.out.println("Connectivity status callback");
                break;
            case APICallbacks.MID_ORDER_CANCEL_FAILURE_ID:
                System.out.println("Order cancel failure callback");
                break;
            case APICallbacks.MID_MEMORY_WARNING:
                System.out.println("memory warning callback");
                break;
            case APICallbacks.MID_STRATEGY_CREATION_RECEIVED:
                System.out.println("Strategy creation callback");
                break;
            case APICallbacks.MID_STRATEGY_CREATION_FAILURE:
                System.out.println("Strategy creation FAILED callback");
                break;
            case APICallbacks.MID_ORDER_SENT_TIMEOUT:
                System.out.println("Order sent timeout callback");
                break;
            case APICallbacks.MID_ORDER_QUEUED_TIMEOUT:
                System.out.println("Order queued timeout callback");
                break;
            case APICallbacks.MID_RESET_ORDERBOOK:
                System.out.println("Reset orderbook callback");
                break;
            default:
                System.out.println("Unprocessed Callback Message: " + messageID +
                        ", length=" + length);
            }
        }
        catch (Throwable t) {
            System.out.println("Error processing callback message " + messageID);
        }
      }


}
